"use strict";
var ref, ref1;
module.exports = ((ref = global.process) == null ? void 0 : ref.env) && typeof ((ref1 = global.process) == null ? void 0 : ref1.env) === "object" ? global.process : require("../../compiled/process");

//# sourceMappingURL=process.js.map