"use strict";
module.exports = function() {
    return Object.assign;
};

//# sourceMappingURL=shim.js.map