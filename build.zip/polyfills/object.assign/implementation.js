"use strict";
module.exports = Object.assign;

//# sourceMappingURL=implementation.js.map