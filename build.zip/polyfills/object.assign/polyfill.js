"use strict";
module.exports = function() {
    return Object.assign;
};

//# sourceMappingURL=polyfill.js.map