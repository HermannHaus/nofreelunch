"use strict";
/* globals self */ var fetch = self.fetch.bind(self);
module.exports = fetch;
module.exports.default = module.exports;

//# sourceMappingURL=index.js.map