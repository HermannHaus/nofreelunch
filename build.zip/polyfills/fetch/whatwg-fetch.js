"use strict";
/* globals self */ exports.Headers = self.Headers;
exports.Request = self.Request;
exports.Response = self.Response;
exports.fetch = self.fetch;

//# sourceMappingURL=whatwg-fetch.js.map