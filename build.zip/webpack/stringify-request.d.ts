export declare function stringifyRequest(loaderContext: any, request: any): string;
