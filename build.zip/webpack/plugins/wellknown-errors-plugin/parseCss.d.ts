import { SimpleWebpackError } from './simpleWebpackError';
export declare function getCssError(fileName: string, err: Error): SimpleWebpackError | false;
