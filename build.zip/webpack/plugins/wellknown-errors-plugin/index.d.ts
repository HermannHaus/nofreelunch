import type { webpack } from 'next/dist/compiled/webpack/webpack';
export declare class WellKnownErrorsPlugin {
    apply(compiler: webpack.Compiler): void;
}
