import { SimpleWebpackError } from './simpleWebpackError';
export declare function getScssError(fileName: string, fileContent: string | null, err: Error): SimpleWebpackError | false;
