export declare function setRequireOverrides(aliases: [string, string][]): void;
export declare function loadRequireHook(aliases?: [string, string][]): void;
export declare function overrideBuiltInReactPackages(): void;
