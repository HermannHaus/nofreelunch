/// <reference types="lodash" />
import { webpack } from 'next/dist/compiled/webpack/webpack';
export declare const loader: import("lodash").CurriedFunction2<webpack.RuleSetRule, webpack.Configuration, webpack.Configuration>;
export declare const unshiftLoader: import("lodash").CurriedFunction2<webpack.RuleSetRule, webpack.Configuration, webpack.Configuration>;
export declare const plugin: import("lodash").CurriedFunction2<webpack.WebpackPluginInstance, webpack.Configuration, webpack.Configuration>;
