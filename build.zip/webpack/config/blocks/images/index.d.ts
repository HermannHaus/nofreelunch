/// <reference types="lodash" />
import { webpack } from 'next/dist/compiled/webpack/webpack';
import { ConfigurationContext } from '../../utils';
export declare const images: import("lodash").CurriedFunction2<ConfigurationContext, webpack.Configuration, Promise<webpack.Configuration>>;
