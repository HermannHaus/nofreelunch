export declare function getCustomDocumentImageError(): string;
