/// <reference types="lodash" />
import { webpack } from 'next/dist/compiled/webpack/webpack';
import { ConfigurationContext } from '../utils';
export declare const base: import("lodash").CurriedFunction2<ConfigurationContext, webpack.Configuration, webpack.Configuration>;
