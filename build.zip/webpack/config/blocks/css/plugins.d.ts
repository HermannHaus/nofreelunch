export declare function getPostCssPlugins(dir: string, supportedBrowsers: string[] | undefined, disablePostcssPresetEnv?: boolean): Promise<import('postcss').AcceptedPlugin[]>;
