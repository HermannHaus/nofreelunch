import { webpack } from 'next/dist/compiled/webpack/webpack';
export declare function getCssModuleLocalIdent(context: webpack.LoaderContext<{}>, _: any, exportName: string, options: object): any;
