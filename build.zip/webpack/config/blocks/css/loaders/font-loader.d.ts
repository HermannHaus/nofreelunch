import { webpack } from 'next/dist/compiled/webpack/webpack';
import { ConfigurationContext } from '../../../utils';
export declare function getFontLoader(ctx: ConfigurationContext, postcss: any, fontLoaderOptions: any): webpack.RuleSetUseItem[];
