export declare function cssFileResolve(url: string, _resourcePath: string, urlImports: any): boolean;
