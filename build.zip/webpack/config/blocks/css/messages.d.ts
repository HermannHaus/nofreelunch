export declare function getGlobalImportError(): string;
export declare function getGlobalModuleImportError(): string;
export declare function getLocalModuleImportError(): string;
export declare function getCustomDocumentError(): string;
export declare function getFontLoaderDocumentImportError(): string;
