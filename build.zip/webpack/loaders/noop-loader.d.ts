import { webpack } from 'next/dist/compiled/webpack/webpack';
declare const NoopLoader: webpack.LoaderDefinitionFunction;
export default NoopLoader;
