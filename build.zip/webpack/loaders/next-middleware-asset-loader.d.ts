/// <reference types="node" />
export default function MiddlewareAssetLoader(this: any, source: Buffer): string;
export declare const raw = true;
