export default function nextFontLoader(this: any): Promise<any>;
