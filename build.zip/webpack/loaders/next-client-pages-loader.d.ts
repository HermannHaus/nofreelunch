export declare type ClientPagesLoaderOptions = {
    absolutePagePath: string;
    page: string;
};
declare function nextClientPagesLoader(this: any): any;
export default nextClientPagesLoader;
