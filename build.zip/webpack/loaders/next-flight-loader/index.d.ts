export default function transformSource(this: any, source: string, sourceMap: any): Promise<any>;
