export declare type EdgeFunctionLoaderOptions = {
    absolutePagePath: string;
    page: string;
    rootDir: string;
};
export default function middlewareLoader(this: any): string;
