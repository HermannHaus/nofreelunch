"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
const NoopLoader = (source)=>source;
var _default = NoopLoader;
exports.default = _default;

//# sourceMappingURL=noop-loader.js.map