export declare function isClientComponentModule(mod: {
    resource: string;
    buildInfo: any;
}): boolean;
export declare const regexCSS: RegExp;
