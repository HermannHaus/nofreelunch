"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getModuleBuildInfo = getModuleBuildInfo;
function getModuleBuildInfo(webpackModule) {
    return webpackModule.buildInfo;
}

//# sourceMappingURL=get-module-build-info.js.map