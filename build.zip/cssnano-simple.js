"use strict";
module.exports = require("next/dist/compiled/cssnano-simple")(require("postcss"));

//# sourceMappingURL=cssnano-simple.js.map