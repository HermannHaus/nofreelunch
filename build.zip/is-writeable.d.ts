export declare function isWriteable(directory: string): Promise<boolean>;
