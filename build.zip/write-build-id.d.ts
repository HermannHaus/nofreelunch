export declare function writeBuildId(distDir: string, buildId: string): Promise<void>;
