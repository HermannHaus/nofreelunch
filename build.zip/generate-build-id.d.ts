export declare function generateBuildId(generate: () => string | null | Promise<string | null>, fallback: () => string): Promise<string>;
