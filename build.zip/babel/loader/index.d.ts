import { NextJsLoaderContext } from './types';
declare const nextBabelLoaderOuter: (this: NextJsLoaderContext, inputSource: string, inputSourceMap: object | null | undefined) => void;
export default nextBabelLoaderOuter;
