export declare function consumeIterator(iter: Iterator<any>): any;
