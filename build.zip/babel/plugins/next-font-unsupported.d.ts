import { PluginObj } from 'next/dist/compiled/babel/core';
export default function NextPageDisallowReExportAllExports(): PluginObj<any>;
