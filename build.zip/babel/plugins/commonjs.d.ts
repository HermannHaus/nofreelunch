import { PluginObj } from 'next/dist/compiled/babel/core';
export default function CommonJSModulePlugin(...args: any): PluginObj;
