export function getParserOptions(options: {
  filename: string
  jsConfig?: any
  [key: string]: any
}): any
export function getJestSWCOptions(...args: any[]): any
export function getLoaderSWCOptions(...args: any[]): any
